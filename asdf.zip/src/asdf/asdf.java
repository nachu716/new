package asdf;
 
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
 
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
 
public class asdf {
    public static void main(String[] args) throws Exception {
        
    	
    	FileWriter fo = new FileWriter("C:\\Users\\ARTISTSHIP3\\Desktop\\ȫ��\\data.doc");
        InputStreamReader reader = new InputStreamReader(System.in);
        
        BufferedReader buff = new BufferedReader(reader);
        
        //System.out.print("input url: ");
       // String url = buff.readLine();
        String url = "https://search.daum.net/search?w=tot&DA=YZR&t__nil_searchbox=btn&sug=&sugo=&q=%EC%8B%A4%EC%8B%9C%EA%B0%84+%EA%B2%80%EC%83%89%EC%96%B4";
        
        System.out.print("input selector: ");
        String selector = buff.readLine();
        
        
        Document doc = Jsoup.connect(url).get();
        
        Elements titles = doc.select(selector);
        
        String output = "";
        
        for(Element e: titles) {
            output += e.text();
            output += "\n";

        }
        
        
        //System.out.println( output.replace("\n\n", "\b") );
        System.out.println( output );
        fo.write(output);
     
        fo.close();
        
    }
}